package bit.Server;
//14.32.18.42
public class Start {
	public static void main(String[] args) {
		TcpIpMultiServer server = new TcpIpMultiServer();
		server.Run();
	}
}
